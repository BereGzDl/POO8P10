/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo8p10;

/**
 *
 * @author González De Luna Berenice
 */
public class SaldoInsuficienteException extends Exception{
    /**
     * Excepciones propias no definidas en el API de Java
     */
     public SaldoInsuficienteException() {
        super("Saldo insuficiente");
    }
}
